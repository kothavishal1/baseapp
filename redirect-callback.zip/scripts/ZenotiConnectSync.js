//JavaScript client code that specifies the URL (with the generated proxy)
var ZconnectsignalRSync = ZconnectsignalRSync || function (HubUrl, HubToken, HolderId) {
    if (!HolderId) {
        $.error('HolderId needs to be defined');
        return;
    }
    this.hubUrl = HubUrl;
    this.hubToken = HubToken;
    this.connection = null;
    this.callback = null;
    this.started = false;
    this.hubProxy = null;
    this.errorCount = 0;
    this.maxErrorCount = 10;
    this.tokenRefreshDt = new Date();
    this.minReconnectInterval = 5000; // in milliseconds
    this.stopCalled = false;
    this.connectionId = null;
    this.holderId = HolderId;

    this.init();

};

if (!window.Log) {
    Log =
    {
        SignalRLog(logMessage, eventName, direction) {
            console.log(arguments)
        }
    }
}



ZconnectsignalRSync.prototype = {
    constructor: ZconnectsignalRSync,
    init: function () {
        var me = this;
        var tryingToReconnect = false;
        this.connection = $.hubConnection(this.hubUrl, { useDefaultPath: false });
       
        this.connection.logging = true;
        this.connection.qs = { "hubToken": this.hubToken };

        var setupProxy = function () {
            me.hubProxy = me.connection.createHubProxy('ZenotiConntectHub');
            me.hubProxy.on('NewResponse', function () { });


        }

        var doneFunc = function () {
            console.log("SignalR Connected");
            Log.SignalRLog("SignalR Connected, transport = " + me.connection.transport.name, 'Connected', 'Processing');
            me.connectionId = me.connection.id;

            me.hubProxy.invoke("joinConnect", me.holderId);
            if (me.callback)
                me.callback.call();
            me.started = true;
            me.errorCount = 0;
        };
         
        var tryRefreshToken = function () {
            var newToken = globalSignalRToken;
            if (new Date() - me.tokenRefreshDt < 60000) {
                Log.SignalRLog('Token has been obtained recently, won\'t be refreshed', 'tryRefreshToken', 'Processing');
                return false;
            }
            Log.SignalRLog('Trying to refresh the token...', 'tryRefreshToken', 'Processing');
            $.ajax({
                type: "POST",
                url: "/Login.aspx/RefreshApiToken",
                data: JSON.stringify({ oldToken: globalSignalRToken, refreshSignalRToken: true }),
                contentType: "application/json; charset=utf-8",
                dataType: "json",
                async: false,
                success: function (msg) {
                    newToken = msg.d;
                },
                error: function (XMLHttpRequest, textStatus, errorThrown) {
                    Log.SignalRLog('Error while refreshing token ' + textStatus, 'tryRefreshToken', 'Processing');
                }
            });

            me.tokenRefreshDt = new Date();

            if (newToken != globalSignalRToken) {
                globalSignalRToken = newToken;
                me.hubToken = globalSignalRToken;
                me.connection.qs = { "hubToken": me.hubToken };
                Log.SignalRLog('Refreshed the expired token', 'tryRefreshToken', 'Processing');
                me.connection.disconnected(function () {
                    Log.SignalRLog('Reconnected to the hub with refreshed token', 'tryRefreshToken', 'Processing');
                });
                return true;
            } else {
                Log.SignalRLog('Token has the same value after refresh. It may be valid', 'tryRefreshToken', 'Processing');
            }
            return false;
        }

        this.connection.error(function (error) {
            Log.SignalRLog('SignalR error: ' + error, 'error', 'Processing');
            me.errorCount++;
            tryRefreshToken();
            if (me.errorCount > me.maxErrorCount) {
                Log.SignalRLog('Max error count reached.', 'error', 'Processing');
            }
        });

        this.connection.connectionSlow(function () {
            Log.SignalRLog('We are currently experiencing difficulties with the connection.', 'connectionSlow', 'Processing');
        });

        this.connection.disconnected(function () {
            if (tryingToReconnect)
                Log.SignalRLog('SignalR connection was disconnected. Will reattempt after few seconds...', 'disconnected', 'Processing');

            me.started = false;
            
            if (me.stopCalled) {
                Log.SignalRLog('SignalR connection was explicitly stopped. Quitting...', 'disconnected', 'Processing');
                return;
            }

            Log.SignalRLog('SignalR connection closed', 'disconnected', 'Processing');
            me.connectionId = null;

            if (me.errorCount <= me.maxErrorCount) {
                var refreshInterval = (me.errorCount <= 0 ? me.minReconnectInterval : (me.minReconnectInterval * me.errorCount));
                setTimeout(function () {
                    if (me.hubProxy === null) {
                        setupProxy();
                    }
                    me.connection.start().done(doneFunc);
                    setTimeout(function (self) {
                        self.updateChatWindowOnReconnect(self);
                    }, me.getRandomDelay(), me);
                }, refreshInterval); // Restart connection after 5 seconds times the number of continuous errors.
            }
        });

        this.connection.reconnecting(function () {
            tryingToReconnect = true;
            me.errorCount++;
            Log.SignalRLog('SignalR is reconnecting...', 'reconnecting', 'Processing');
            tryRefreshToken();
        });

        this.connection.reconnected(function () {
            tryingToReconnect = false;
            me.errorCount = 0;
            Log.SignalRLog('SignalR has reconnected the session.', 'reconnected', 'Processing');
            setTimeout(function (self) {
                self.updateChatWindowOnReconnect(self);
            }, me.getRandomDelay(), me);
        });

        setupProxy();

        this.connection
            .start()
            .done(doneFunc)
            .fail(function () { Log.SignalRLog('SignalR could not connect', 'connectFail', 'Processing'); });
    },
    stopConnection: function () {
        this.stopCalled = true;
        this.connection.stop();
    },
    onNewReseponse: function (callback) {
        if (this.hubProxy)
            this.hubProxy.on('newResponse', function () {
                Log.SignalRLog('Reception of newResponse', 'onNewResponse', 'In');
                callback.apply(this, arguments);
            });
    },
    onReadingUnreadMsg: function (callback) {
        if (this.hubProxy)
            this.hubProxy.on('readResponse', function () {
                Log.SignalRLog('Reception of readResponse', 'onReadingUnreadMsg', 'In');
                callback.apply(this, arguments);
            });
    },
    onNewNotification: function (callback) {
        if (this.hubProxy)
            this.hubProxy.on('newNotification', function () {
                Log.SignalRLog('Reception of newNotification', 'onNewNotification', 'In');
                callback.apply(this, arguments)
            });
    },
    updateChatWindowOnReconnect: function (self) {
        var me = (self !== undefined ? self : this);
        if (new Date() - me.lastRefreshDate > me.maxReloadInterval) {
            me.lastRefreshDate = new Date();
            me.reloadChatWindow();
            Log.SignalRLog('Reloaded the chat window after signalr disconnection', 'updateChatWindowOnReconnect', 'Processing');
        }
    },

    getRandomDelay: function random() {
        return (Math.random() * 300000).toFixed(0);
    },

    reloadChatWindow: function () {
        GetRepliedusers();
        ShowConversation(CurrentUserId, CurrentGuestMobile);
        return true;
    }
};

var $ZconnectsignalR;
//$(function () {
//    $signalR = new signalRSync();
//});

var myEvent = window.attachEvent || window.addEventListener;
var chkevent = window.attachEvent ? 'onbeforeunload' : 'beforeunload'; /// make IE7, IE8 compitable


myEvent(chkevent, function (e) { // For >=IE7, Chrome, Firefox
    if ($ZconnectsignalR && $ZconnectsignalR.connection && $ZconnectsignalR.connection.id ) {
        if (window.opener && window.opener.Log) {
            window.opener.Log.SignalRLog('closing connection :' + $ZconnectsignalR.connection.id);
        }
        
        $ZconnectsignalR.connection.stop();
    }

});