
//Global variable for JS file
var AllMediumsDisabledDueToInValidMobileNumber = false;
var callObject;
var audioObj;
var userMedia = ( navigator.getUserMedia || navigator.webkitGetUserMedia || navigator.mozGetUserMedia || navigator.msGetUserMedia );
// navigator.mediaDevices.getUserMedia({audio: true})
//   .then(stream => audio.srcObject = stream)
//   .catch(e => console.log(e));
navigator.mediaDevices.getUserMedia({audio: true}).then(function(stream){
    console.log('----stream----');
    console.log(stream);
    audioObj = stream; }).catch(e => console.log(e));
var notificationData = {};
// var notificationData = {
//     'isSoundNotification': true,
//     'isBrowserNotification': true,
//     'isBrowserWithKeywords': true,
//     'isSoundWithKeywords': true,
//     'keywords': ['abc', 'xyz']
// }
var msgContainsKeyword = false;
var notificationMsg = {
    'name': '',
    'msg': '',
    'userId':'',
    'mobilePhone':'',
    'msgId': null,
}

const notificationCategory = {
    'NOTE': 'note',
    'OTHER': 'other',
}

EnableSignalRForConnect=(typeof EnableSignalRForConnect === "undefined")?true:EnableSignalRForConnect;
EnableSignalRForConnect_MMS=(typeof EnableSignalRForConnect_MMS === "undefined")?true:EnableSignalRForConnect_MMS;
globalSignalRUrl=(typeof globalSignalRUrl !== "undefined")?globalSignalRUrl:'https://apiSreZConnect.zenotibeta.com/signalr';
globalSignalRToken=(typeof globalSignalRToken !== "undefined")?globalSignalRToken:'AN:ezconnect|$ARD#BkbOMF1PNWFDiVje3z7sszt/xltqPvVa/VzrzXIJRRaAyJW2sa0WNDNfZu8eFhCGlS7GVKS6AwtD7XVcep/1pTocCnT4XNmL7PPnyVzJ2xMNYuAmVAzkOG+sFfoVJal1I2csxghbj2NcazYh5P3uyc3Rnn729SdSXuKrK0n9dxHOI4jFJyyDepJEKGLiCFNaYfFYADhpkGVkuYtnx7nNQs38tdjbnIIdgYRYPTazqJ1jdN8ogkmEynsEv7tKmqHYZDLtzN+6nq1sXBpfzzJ+AbrQNlTpM8JAr7OPG47sOw/Q0iPieHrDkaM/FVXTjv7zwiv7+iSLHtlL1FO/lUMZhJLFbJEZL5dnGYE=';
strHolderId=(typeof strHolderId !== "undefined")?strHolderId : '0ebfcafe-a3d0-4f23-b3dd-cbab4e493cae';
SendSMSPermission = (typeof SendSMSPermission !== "undefined")?SendSMSPermission:true;
EnableSignalRForConnect = (typeof EnableSignalRForConnect === "undefined") ? true : EnableSignalRForConnect;
EnableSignalRForConnect_MMS = (typeof EnableSignalRForConnect_MMS === "undefined") ? true : EnableSignalRForConnect_MMS;
globalSignalRUrl = (typeof globalSignalRUrl !== "undefined") ? globalSignalRUrl : 'https://apiSreZConnect.zenotibeta.com/signalr';
globalSignalRToken = (typeof globalSignalRToken !== "undefined") ? globalSignalRToken : 'AN:ezconnect|$ARD#BkbOMF1PNWFDiVje3z7sszt/xltqPvVa/VzrzXIJRRaAyJW2sa0WNDNfZu8eFhCGlS7GVKS6AwtD7XVcep/1pTocCnT4XNmL7PPnyVzJ2xMNYuAmVAzkOG+sFfoVJal1I2csxghbj2NcazYh5P3uyc3Rnn729SdSXuKrK0n9dxHOI4jFJyyDepJEKGLiCFNaYfFYADhpkGVkuYtnx7nNQs38tdjbnIIdgYRYPTazqJ1jdN8ogkmEynsEv7tKmqHYZDLtzN+6nq1sXBpfzzJ+AbrQNlTpM8JAr7OPG47sOw/Q0iPieHrDkaM/FVXTjv7zwiv7+iSLHtlL1FO/lUMZhJLFbJEZL5dnGYE=';
strHolderId = (typeof strHolderId !== "undefined") ? strHolderId : '0ebfcafe-a3d0-4f23-b3dd-cbab4e493cae';
SendSMSPermission = (typeof SendSMSPermission !== "undefined") ? SendSMSPermission : true,

function bindGlobalVar(signalRUrl, signalRToken, holderId, enableSignalR) {
    globalSignalRUrl = signalRUrl;
    globalSignalRToken = signalRToken;
    strHolderId = holderId;
    globalEnableSignalR = enableSignalR;
    console.log('Global variables binded ' + signalRUrl);
}

function resetNotificationMsg({name='', msg='', userId='', mobilePhone='', msgId=null}){
    notificationMsg.msg= msg;
    notificationMsg.name= name;
    notificationMsg.mobilePhone = mobilePhone;
    notificationMsg.userId = userId;
    notificationMsg.msgId = msgId;
}

//This function will init all global var in JS and then it will pass it to Dart
function bindGlobalVarDart() {
    //alert('We are here at bindGlobalVarDart');

    document.getElementsByTagName("body")[0].setAttribute("spellcheck", "true");
    CheckCreditsAvailabilityForConnect();
    var globalVar={
        "centerId": (typeof globalCenterId !== "undefined")?globalCenterId:'4257cd7c-2134-45d7-91f5-e616dbb04994',
        "organizationId": (typeof globalOrganizationId !== "undefined")?globalOrganizationId:'c3df0f67-50d0-44e1-84d1-e5ee08af5625',
        "apiToken": (typeof globalWebApiToken !== "undefined")?globalWebApiToken:'AN:ezconnect|$ARD#XFEh/RZ0UWBPRnxrT0CR789anVppy/HuxSOEOO1Y4RIoZp2ETbbktFrt8mX6wq90bYtBe/qa8joOFzOtrwuAiqVfH8my+PHy22+KlZEfA2X5dBntEnF0vJWUhOli1Rfh/EZDUs1MacUrWJUWlfWZbNgWdiJFOXbwWbcFLr5oHhp3CZxJfg/zK86jHZtCJIkXc0EuUXrtWTSSAA+czF52UV62ROTKz92ieeEsf/wW9jlxPoGwcvvj93RMW6HJH/a0nXKPC61gh8dYUAbdvLCOkcQlERvklK+VfNQJhkXAagmhdfisWbtBCsHseBKtre7v7ATvmVkd/dL/7FQayXj/R1oYgP18ws7Wmqc=',
        "signalRUrl": (typeof globalSignalRUrl !== "undefined")?globalSignalRUrl:'https://apiSreZConnect.zenotibeta.com/signalr',
        "signalRToken": (typeof globalSignalRToken !== "undefined")?globalSignalRToken:'AN:ezconnect|$ARD#j+yUhfLCf8yLX/XNZth08XrEGIdiNS+rkYkVGyzm1hurJlg9/rjcYJt2tiWme3b4WoBqfwms2sfyy56RYDt+Jazws3XskQ39NOTaijL8F9hRH4PTIr2AAkQKPI/wm2D0Hb1gdHNwujaktSqem4xUQjqb3e2xFDZATGZuhSGrAXBR3Rtc9cacKg0y4LkW9UQpv82/Zl/dB9cL7nCHRJqEAm0ze4PtDKLns7TNT8R2h7D41TpUC7eWnSW5ZUnoq5Mh14MuJvYq8VwtX6hZ8xpdPmfCWJJZnxpowcUB84AzUBEeBHO5Du1Hx2R/AyT4pHw84l6KhF02XK5F3iFIf6RfEBOsRpfQPMKSArY=',
        "holderId": (typeof strHolderId !== "undefined")?strHolderId:'0ebfcafe-a3d0-4f23-b3dd-cbab4e493cae',
        "userId": (typeof globalUserId !== "undefined")?globalUserId:'5b2a4f2a-489b-45bf-9fc7-b2d413c2870b',
        "globalCurrentCenterDateTime": (typeof globalCurrentCenterDateTime !== "undefined")?convertDateTime(globalCurrentCenterDateTime):convertDateTime('Tue Mar 29 2022 01:20:55 GMT+0530 (India Standard Time)'),
        "userName":(typeof globalUserFName !== "undefined")? unescape(globalUserFName) +' '+ unescape(globalUserLName) :"General_mgr mgr",
        "userRole": (typeof globalUserBaseRole !== "undefined")?globalUserBaseRole:'Owner',
        "apiBaseURL": (typeof globalWebApiUrl !== "undefined")?globalWebApiUrl:'https://apiezconnect.zenotibeta.com/',
        "globalCenterCountryCode" : (typeof globalCenterCountrycode !== "undefined")?globalCenterCountrycode :'IN',
        "centerTimeZoneOffset" : (typeof centerTimeZone !== "undefined")?getTimeZoneMinutes(centerTimeZone) : 0,//getTimeZoneMinutes('(UTC+05:30) New Delhi'),
        "SendSMSPermission": (typeof SendSMSPermission !== "undefined")?SendSMSPermission:true,
        "SMSCapability": (typeof SMSCapability !== "undefined")?SMSCapability:true,
        "SMSCredits": (typeof SMSCredits !== "undefined")?SMSCredits:true,
        "WhatsAppCapability": (typeof WhatsAppCapability !== "undefined")?WhatsAppCapability:true,
        "WhatsAppCredits": (typeof WhatsAppCredits !== "undefined")?WhatsAppCredits:true,
        "switchUIvalue" :(typeof EnableConnectSwitch !== "undefined")?EnableConnectSwitch:false,
        "enableSwitchWelcomeMessage" :(typeof enableSwitchWelcomeMessage !== "undefined")?enableSwitchWelcomeMessage:true,
        

        "AllowSendWhatsAppTemplates" : (typeof AllowSendWhatsAppTemplates !== "undefined")?AllowSendWhatsAppTemplates:true,
        "GainSightKey" :(typeof GainSightKey !== "undefined")?GainSightKey:'',
        "IsMasked":(typeof ViewGuestData !== "undefined")?!ViewGuestData:false,
        "SelectedGuestID":(typeof strUserId !== "undefined")?strUserId:'',
        "GuestLabel":(typeof GuestLabel !== "undefined")? GuestLabel:'',
        "enableSMSMMS": (typeof enableSMSMMS !== "undefined")?enableSMSMMS:true,
        "enableWhatsAppMMS": (typeof enableWhatsAppMMS !== "undefined")?enableWhatsAppMMS:true,
        "isSBU": (typeof isSBU !== "undefined") ? isSBU : false,
        "fbToken": (typeof fbToken !== "undefined") ? fbToken : '',
        "isFBActive": (typeof isFBActive !== "undefined") ? isFBActive : true,
        "fbPageId": (typeof fbPageId !== "undefined") ? fbPageId : '',
        "podName":(typeof podName !== "undefined") ? podName : '',
        "accountName":(typeof globalAccountName !== undefined) ? globalAccountName : '',
        "utilityAppUrl": (typeof utilityAppUrl !== undefined) ? utilityAppUrl : '',
        "EnableInternationalSMS": (typeof EnableInternationalSMS !== "undefined") ? EnableInternationalSMS : false,
        "disableSSO": (typeof disableSSO !== "undefined") ? disableSSO : false,
        "EnableBotAutoResponder": (typeof EnableBotAutoResponder !== "undefined") ? EnableBotAutoResponder : false,
        "EnablePrivateNote": (typeof EnablePrivateNote !== "undefined") ? EnablePrivateNote : false,
        "EnableVoice": (typeof EnableVoice !== "undefined") ? EnableVoice : false,
        "instagramToken": (typeof instaToken !== "undefined") ? instaToken : '',
        "isInstaActive": (typeof isInstaActive !== "undefined") ? isInstaActive : true,
        "instagramPageId": (typeof instaPageId !== "undefined") ? instaPageId : '',
        "instagramBusinessId": (typeof instagramBusinessId !== "undefined") ? instagramBusinessId : '',
    };
    onBindGlobalVar(JSON.stringify(globalVar));
}

function convertDateTime(str) {
    console.log(str);
    var date = new Date(str);
    var mnth = ("0" + (date.getMonth() + 1)).slice(-2);
    var day = ("0" + date.getDate()).slice(-2);
    var hour = ("0" + (date.getHours())).slice(-2);
    var minutes = ("0" + date.getMinutes()).slice(-2);
    console.log('This is center time');
    console.log([date.getFullYear(), mnth, day].join("-") + ' ' + date.getHours() + ':' + date.getMinutes());

    return [date.getFullYear(), mnth, day].join("-") + ' ' + hour + ':' + minutes;
}

function getTimeZoneMinutes(strTimeZone) {
    //var strTimeZone='UTC+05:30 India';
    try {
        var strHours = strTimeZone.substring(5, 7);
        var strMinutes = strTimeZone.substring(8, 10);
        var totalMinutes = parseInt(strHours) * 60 + parseInt(strMinutes);
        if (strTimeZone.indexOf('+') > 0) {
            return totalMinutes;
        }
        else {
            return -totalMinutes;
        }
    } catch (error) {
        return 0;
    }

}

function connectSignalr() {
    $ZconnectsignalR = $ZconnectsignalR || new ZconnectsignalRSync(globalSignalRUrl, globalSignalRToken, strHolderId);
    //alert("Step2");
    var addApptFunc = function (message) {
            if(message!=undefined)
            {
                console.log();(JSON.stringify(message));
                resetNotificationMsg({
                    msg: message.Message,
                    name: message.Name,
                    userId: message.UserId,
                    mobilePhone: message.MobilePhone,
                });
//                notificationMsg.msg=message.Message;
//                notificationMsg.name=message.Name;
//                notificationMsg.userId = message.UserId;
//                notificationMsg.mobilePhone = message.MobilePhone;
//                notificationMsg.messageId = null;  // TODO: get the key for Id of message
                console.log();(JSON.stringify(notificationMsg));
                console.log();(JSON.stringify(notificationData));
                for(i=0;i<notificationData.settings.keywords.length;i++)
                {
                    if(message.Message.toLowerCase().includes(notificationData.settings.keywords[i].toLowerCase())){
                        msgContainsKeyword=true;
                    break;
                }
            }
            notify(notificationData, notificationMsg);
            newResponseFromSignalR(JSON.stringify(message));
        }

        else
            onReadingUnreadMsgFromSignalR();
        if (message != undefined) {

        }
    };

        var markAsUnreadSignalRApptFunc = function (message) {
            onMarkAsUnreadMsgFromSignalR();
        };

        var newPrivateNoteSignalRApptFunc = function (message) {
            signalRPrivateNoteReceived(message);
        };

    $ZconnectsignalR.onNewReseponse(addApptFunc);
    $ZconnectsignalR.onReadingUnreadMsg(addApptFunc);
        $ZconnectsignalR.onMarkAsUnreadMsg(markAsUnreadSignalRApptFunc);
        $ZconnectsignalR.onNewPrivateNote(newPrivateNoteSignalRApptFunc);
}

function testNotification() {
    //alert('hello');
    //notificationMsg.msg='This is yest message';
    //notificationMsg.name='Test User';
    //notificationData.settings.is_sound_with_keywords=false;
    //notificationData.settings.is_browser_notification=true;
    //notificationData.settings.is_sound_notification=true;
    message = { UserId: '083b4864-c8e8-4bcb-895d-f4584519a749', Message: 'Desktop/Sound Notification check hello', IsResponse: true, MobilePhone: '8095444269', Name: 'Bala Krishna', HolderId: 'ce3b4e1d-2e02-4d63-8d5b-b480ad909ff1', Source: 0 };
    signalRMessageReceived(message);
}

function hideJsLoader() {
    /* Initial loader hide call that needs to be called from main.dart once the app boots up */
    var loadingContainer = document.getElementById('loading-container');
    if (loadingContainer) {
      document.body.removeChild(loadingContainer);
    }
  }



$(document).ready(function () {
    window.moveTo((screen.availWidth / 3) - 200, (screen.availHeight / 2) + 100);
    window.resizeTo((screen.availWidth / 2) + 200, screen.availHeight - 10);
    //Gainsight
    if (EnableGainsight) {
        GainsightInitializer();
    }

    //aptrinsic('identify', { id: '<%= Core.MMSAppContext.GetAppContext().GetUserPreferences(Core.MMSAppContext.GetAppContext().MMSContext.EmpUserId).Id%>' }, { id: '<%=Core.MMSAppContext.GetAppContext().GetOrgPreferences(Core.MMSAppContext.GetAppContext().MMSContext.OrganizationId).Name%>' });

    if (EnableSignalRForConnect && EnableSignalRForConnect_MMS) {
        $ZconnectsignalR = $ZconnectsignalR || new ZconnectsignalRSync(globalSignalRUrl, globalSignalRToken, strHolderId);

        var addApptFunc = function (message) {
            if (message != undefined) {
                signalRMessageReceived(message);
            }
            else {
                onReadingUnreadMsgFromSignalR();
                if (message != undefined) {
                }
            }

        };
        var markAsUnreadSignalRApptFunc = function (message) {
            onMarkAsUnreadMsgFromSignalR();
        };

        var newPrivateNoteSignalRApptFunc = function (message) {
            signalRPrivateNoteReceived(message);
        };

        $ZconnectsignalR.onNewReseponse(addApptFunc);
        $ZconnectsignalR.onReadingUnreadMsg(addApptFunc);
        $ZconnectsignalR.onMarkAsUnreadMsg(markAsUnreadSignalRApptFunc);
        $ZconnectsignalR.onNewPrivateNote(newPrivateNoteSignalRApptFunc);
    }
    else {

    }
});

function signalRPrivateNoteReceived(message){
    if(globalUserId != null){
        // TODO: Check if this is correct way to check current user id or consider userId from dart code after binding
        if((message.EmployeeIds != null) && (message.EmployeeIds.includes(globalUserId))){
            // 1. Inform the Flutter App
            onNewPrivateNoteFromSignalR(JSON.stringify(message));
            // 2. Desktop Notification
            resetNotificationMsg({
                msg: parsePrivateNoteMsg(message.Message),
                name: `${message.Name} added a note`,
                mobilePhone: message.MobilePhone,
                userId: message.UserId,
                msgId: message.NotePk,
            });
//            notificationMsg.msg= parsePrivateNoteMsg(message.Message);
//            notificationMsg.name= `${message.Name} added a note`;
//            notificationMsg.mobilePhone = message.MobilePhone;
//            notificationMsg.userId = message.UserId;
//            notificationMsg.msgId = message.NotePk;
            notify(notificationData, notificationMsg, true, notificationCategory.NOTE);
        }
    }
    
}

function signalRMessageReceived(message){
    msgContainsKeyword=false;
    console.log();(JSON.stringify(message));
    resetNotificationMsg({
        msg: message.Message,
        name: message.Name,
        mobilePhone: message.MobilePhone,
        userId: message.UserId,
    });
//    notificationMsg.msg=message.Message;
//    notificationMsg.name=message.Name;
//    notificationMsg.mobilePhone = message.MobilePhone;
//    notificationMsg.userId = message.UserId;
//    notificationMsg.messageId = null;  // TODO: get the key for Id of message
    console.log();(JSON.stringify(notificationMsg));
    console.log();(JSON.stringify(notificationData));
    for(i=0;i<notificationData.settings.keywords.length;i++)
    {
        if(message.Message.toLowerCase().includes(notificationData.settings.keywords[i].toLowerCase())){
            msgContainsKeyword=true;
            break;
        }
    }
    notify(notificationData, notificationMsg);
    newResponseFromSignalR(JSON.stringify(message));
}

function getIDSToken() {
    if(window.sessionStorage.getItem('user'))
        return JSON.parse(window.sessionStorage.getItem('user'))?.access_token;
    else  
        return window.sessionStorage.getItem('break-glass-token'); 
}

function CheckCreditsAvailabilityForConnect() {
    var DTOdata = { 'CenterId': globalCenterId, 'CheckWhatsAppCredits': WhatsAppCapability}
    var token='';
    if(disableSSO){
        token = globalWebApiToken;
    }
    else {
        token = getIDSToken();
    }

    $.ajax({
        url: globalWebApiUrl + '/api/Appointments/CreditsAvailabilityForConnect',
        type: 'GET',
        headers: { "authorization": 'Bearer ' + token},//globalWebApiToken },
        data: DTOdata,
        contentType: "application/json; charset=utf-8",
        async: false,
        dataType: "json"

    }).done(function (data) {
        IsCreditsAvailableForConnect = data.Success;
        console.log('IsCreditsAvailableForConnect : ' + IsCreditsAvailableForConnect);
        if (SMSCapability) {
            SMSCredits = ((IsCreditsAvailableForConnect & SMSMediumCapability) == SMSMediumCapability)
        }
        if (WhatsAppCapability) {
            WhatsAppCredits = ((IsCreditsAvailableForConnect & WhatsAppMediumCapability) == WhatsAppMediumCapability)
        }
        console.log('SMSCapability : ' + SMSCapability + ' WhatsAppCapability:' + WhatsAppCapability);
        //console.log('SMSCredits : '+SMSCredits +' WhatsAppCredits :'+WhatsAppCredits);
    }).fail(function (xhr, status, error) {
        //ShowError();
    });
}


function bindGlobalVar(signalRUrl, signalRToken, holderId, enableSignalR) {

}

function bindNotificationSettings(notificationSettings) {
    notificationData = JSON.parse(notificationSettings);
    //alert(JSON.stringify(notificationData.settings.keywords));
    //console.log('notificationData:' + JSON.stringify(notificationData));
    //testNotification();
}

function notifySound() {
    var audio = new Audio('../ezconnect/icons/NotificationSound.mp3');
    audio.play();
}

function notify(notificationData, notificationMsg, ignoreKeyWordsSettings=false, category=notificationCategory.OTHER) {
    if (isSBU != null && isSBU != undefined && isSBU) {
        return;
    }
    function Shownotification() {
        var options = {
            body: notificationMsg.msg,
            silent: true,
            data: {
                notificationCategory: category,
                userId: notificationMsg.userId,
                mobilePhone: notificationMsg.mobilePhone,
                messageId: notificationMsg.msgId
            }
            //icon: 'https://img.icons8.com/color/search',
        }
        if (notificationData.settings.is_sound_notification) {
            if(ignoreKeyWordsSettings){
                notifySound();
            }else{
                if(notificationData.settings.is_sound_with_keywords && msgContainsKeyword) {
                notifySound();
            } else if (notificationData.settings.is_sound_with_keywords == false) {
                notifySound();
            }
        }
            
        }
        if (notificationData.settings.is_browser_notification) {
            if(ignoreKeyWordsSettings){
                const notification = new Notification(notificationMsg.name, options);
                notification.onclick = (event)=> {
                        onDesktopNotificationClick(JSON.stringify(event.currentTarget.data));
                        parent.focus();
                        window.focus(); //just in case, older browsers
                        notification.close();
                    };
            }else{
                if(notificationData.settings.is_browser_with_keywords && msgContainsKeyword){
                    const notification = new Notification(notificationMsg.name, options);
                    notification.onclick = (event)=> {
                          onDesktopNotificationClick(JSON.stringify(event.currentTarget.data));
                          parent.focus();
                          window.focus(); //just in case, older browsers
                          notification.close();
                        };
                //setTimeout(n.close.bind(n), 3000);
            } else if (notificationData.settings.is_browser_with_keywords == false) {
                    const notification = new Notification(notificationMsg.name, options);
                    notification.onclick = (event)=> {
                          onDesktopNotificationClick(JSON.stringify(event.currentTarget.data));
                          parent.focus();
                          window.focus(); //just in case, older browsers
                          notification.close();
                        };
                //setTimeout(n.close.bind(n), 3000);
            }
            }
            
        }
    };
    if (Notification.permission == "granted") {
        Shownotification();
    } else if (Notification.permission != 'denied') {
        Notification.requestPermission().then(permission => {
            Shownotification();
        });
    }
}

function getFormatedPhoneNumber(countryCode, phoneNumber, format) {
    // console.log("*********************");
    console.log(countryCode + ' -- ' + phoneNumber);
    // console.log("*********************");
    if (format == 'local') {
        return formatE164(countryCode, phoneNumber);
    } else if (format == 'international') {
        return formatInternational(countryCode, phoneNumber);
    }

}
// ---------- update feedback data from new UI to old UI---------------
function updateFeedbackData(reasonText, commentText) {
    aptrinsic('track', 'connect_switch_feedback', { "feedbacktype": reasonText, "feedbackcomment": commentText });
    trackAppEvent('connect_switch_feedback', { "feedbacktype": reasonText, "feedbackcomment": commentText });
}

function triggerGainsightCustomEvent(eventName) {
    try {
        aptrinsic('track', eventName);
    } catch (error) {
        return;
    }
}

//Start - Gainsight Integration
function GainsightInitializer() {
    aptrinsic('identify',
        {
            //User Attributes
            id: globalUserId,
            signupDate: new Date().getTime(),
            firstName: globalUserFName,
            lastName: globalUserLName,
            //email:globalUserEmail,
            //Custom Attributes
            centerId: globalCenterId,
            centerName: strCenterName,
            orgId: globalOrganizationId,
            orgName: strOrgName,
            appVersion: 'V2'
        },
        {
            //Account Attributes
            id: globalOrganizationId,
            name: strOrgName
        }
    );
}
//End - Gainsight Integration

globalChannelFBorInsta=0;//1=FB 2=Instagram
//Facebook Start
globalFBSignInResponse="";
function fnFBPopUp() {
    globalFBSignInResponse="";
    globalChannelFBorInsta=1;
    //var myWindow = window.open('https://www.facebook.com/v12.0/dialog/oauth?client_id=1141783956359661&display=popup&scope=public_profile,email,pages_messaging,pages_show_list&response_type=code%20token&redirect_uri=https://localhost:44362/Page1.aspx&state={"{accountname=dev,pod=AMR03,centerId=asdfre1234fdder}"}', "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400");
    //var myWindow = window.open('https://www.facebook.com/v12.0/dialog/oauth?client_id=1141783956359661&display=popup&scope=public_profile,email,pages_messaging,pages_show_list&response_type=code%20token&redirect_uri=https://localhost:44338/FB/Auth&state={"{accountname='+globalAccountName+',pod='+ podName+',centerId='+globalCenterId+',orgId='+globalOrganizationId+',isOrgConnect=0}"}', "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400");
    var myWindow = window.open('https://www.facebook.com/v12.0/dialog/oauth?client_id='+fbAppID+'&display=popup&scope=public_profile,email,pages_messaging,pages_show_list&response_type=code%20token&redirect_uri='+utilityAppUrl+'/EzConnect/Auth&state={"{accountname='+globalAccountName+',pod='+ podName+',centerId='+globalCenterId+',orgId='+globalOrganizationId+',isOrgConnect=0}"}', "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=500,width=600,height=400");

    myWindow.beforeunload = function () {
        alert("Unload Window :" + myWindow.location.href);
    }
    //myWindow.document.write("<p>This window's name is: " + myWindow + "</p>");
    var loop = setInterval(function () {
        if (myWindow.closed) {
            clearInterval(loop);
        }
    }, 1000); 
}
function fnInstagramPopUp() {
    globalFBSignInResponse="";
    globalChannelFBorInsta=2;
    //var myWindow = window.open('https://www.facebook.com/v12.0/dialog/oauth?client_id=1141783956359661&display=popup&scope=public_profile,email,pages_messaging,pages_show_list&response_type=code%20token&redirect_uri=https://localhost:44362/Page1.aspx&state={"{accountname=dev,pod=AMR03,centerId=asdfre1234fdder}"}', "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400");
    //var myWindow = window.open('https://www.facebook.com/v12.0/dialog/oauth?client_id=1141783956359661&display=popup&scope=public_profile,email,pages_messaging,pages_show_list&response_type=code%20token&redirect_uri=https://localhost:44338/FB/Auth&state={"{accountname='+globalAccountName+',pod='+ podName+',centerId='+globalCenterId+',orgId='+globalOrganizationId+',isOrgConnect=0}"}', "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=500,left=500,width=400,height=400");
    var myWindow = window.open('https://www.facebook.com/v12.0/dialog/oauth?client_id='+fbAppID+'&display=popup&scope=public_profile,email,pages_messaging,pages_show_list,instagram_basic,instagram_manage_messages,pages_manage_metadata,pages_read_engagement&response_type=code%20token&redirect_uri='+utilityAppUrl+'/EzConnect/Auth&state={"{accountname='+globalAccountName+',pod='+ podName+',centerId='+globalCenterId+',orgId='+globalOrganizationId+',isOrgConnect=0,instagram=1}"}', "_blank", "toolbar=yes,scrollbars=yes,resizable=yes,top=100,left=500,width=600,height=400");

    myWindow.beforeunload = function () {
        alert("Unload Window :" + myWindow.location.href);
    }
    //myWindow.document.write("<p>This window's name is: " + myWindow + "</p>");
    var loop = setInterval(function () {
        if (myWindow.closed) {
            clearInterval(loop);
        }
    }, 1000); 
}
window.addEventListener("message", function (event) {
    if (event.origin ===  utilityAppUrl) {
        // something from an unknown domain, let's ignore it
        globalFBSignInResponse = JSON.parse(event.data);
        //alert(JSON.stringify(event.data));
        if(globalFBSignInResponse.data.PageData.data.length>0){
            if(globalChannelFBorInsta==1){
            showFaceBookPageConfigurationPopup(JSON.stringify(globalFBSignInResponse.data.PageData.data),globalFBSignInResponse.data.Token);
        }
            else if(globalChannelFBorInsta==2){
                var instaPageData=[];
                for(i=0;i<globalFBSignInResponse.data.PageData.data.length;i++){
                var instaCheck= getInstagramBusinessAccount(globalFBSignInResponse.data.Token,globalFBSignInResponse.data.PageData.data[i].id)
                    if (instaCheck != undefined) {
                        var temp=$.grep(globalFBSignInResponse.data.PageData.data, function(element){ return element.id == globalFBSignInResponse.data.PageData.data[i].id; })[0];
                        temp.name=temp.name+'('+instaCheck.username+')';
                        temp.instaAccountName=instaCheck.username;
                        temp.instaID=instaCheck.id;
                        instaPageData.push(temp);
        
                        //alert("Instagram account is linked with page " + instaCheck.id+' and Business Account ID :'+instaCheck.username);

                        //break;
                    }
                }
                if(instaPageData.length>0){
                    showInstagramPageConfigurationPopup(JSON.stringify(instaPageData),globalFBSignInResponse.data.Token);
                }
            }
            
        }
        globalChannelFBorInsta=0;
        return;
    }
    // can message back using event.source.postMessage(...)
});
function getInstagramBusinessAccount(token, pageId) {
    var instaAccountfound;
    //https://graph.facebook.com/v12.0/134895793791914?fields=instagram_business_account&access_token=userToken;
    $.ajax({
        type: "GET",
        async: false,
        url: "https://graph.facebook.com/v12.0/" + pageId + "?fields=instagram_business_account{id,name,username}&access_token=" + token,
        //data: "{'url':'" + window.location.href + "'}",
        contentType: "application/json; charset=utf-8",
        dataType: "json",
        success: function (msg) {
            //alert(JSON.stringify(msg, null, 4));
            //debugger;
            if (msg.instagram_business_account != undefined) {

                instaAccountfound= msg.instagram_business_account;
            }
            //window.close();
        },
        error: function (XMLHttpRequest, textStatus, errorThrown) {
            alert(JSON.stringify(XMLHttpRequest));
            alert(textStatus);
        }
    });
    return instaAccountfound;
}
//utilityAppUrl = "https://0827-2405-201-5800-e0a8-f590-814b-3e4e-69bf.ngrok.io";
// if(window.location.host.indexOf("zenotibeta.com")>0){
//     utilityAppUrl="https://utilities.zenotibeta.com";
// }else if(window.location.host.indexOf("zenoti.com")>0){
//     utilityAppUrl="https://utilities.zenoti.com";
// }
// if(window.location.host.toLowerCase().indexOf('dev.zenoti.com')>=0){
//     utilityAppUrl = "https://5245-2405-201-5800-e0f5-4cd2-b913-5d44-a29e.ngrok.io";
// }
    
// var fbAppID = '1141783956359661';
//var utilityAppUrl="https://f714-2405-201-5800-e0f5-f172-3da2-6e08-cac.ngrok.io";

//--------------------------voice call-----------------------------
function initiateVoiceClientSDK(incomingCallsCheck) {
    startupClient(incomingCallsCheck);
}

function rejectIncomingCall() {
    callObject.reject();
}
function acceptInComingCall() {
    callObject.accept();
}

function disconnectVoiceCall() {
    callObject.disconnect();
}
function muteVoiceCall(value) {
    callObject.mute(value);
}

function statusNotificationFromSDK(data) {
    voiceCallStatusNotification(data);

}
function notifyIncomingCallDetail(number, callDetail, callSid) {
    callObject = callDetail;
    notifyIncomingCall(number,callSid);
}

function notifyOutgoingCallDetail(callDetail){
    callObject = callDetail;
}
function browserToPhoneCall(mobileNumber, countryCode, voiceCallNumber) {
    //console.log(mobileNumber+" b2PhoneCall "+ countryCode);
    makeOutgoingCall(mobileNumber,countryCode, voiceCallNumber);
}


