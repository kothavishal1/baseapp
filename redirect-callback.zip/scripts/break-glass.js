var urlSearchParams = new URLSearchParams(window.location.search);
var params = Object.fromEntries(urlSearchParams.entries());
window.localStorage.setItem('break_glass_token', params.processor_id);
var httpPath = window.location.origin;
var httpsPath = httpPath.replace('http:','https:');
window.location.replace(httpsPath);