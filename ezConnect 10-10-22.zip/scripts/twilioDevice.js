var call;
var callSid=null;
varincomingCallCapability=true;
function startupClient(incomingCallsCheck) {
    incomingCallCapability=incomingCallsCheck;
    let xhr = new XMLHttpRequest();
    xhr.open('GET', 'https://mahogany-beagle-9825.twil.io/capability-token');
    var dataInfo = {};
    try {
        xhr.send();
        xhr.onreadystatechange = function () {
            if (xhr.status == 200 && xhr.readyState == 4) {
                obj = JSON.parse(xhr.response);
                token = obj.token;
                intitializeDevice(token);
            }
        }

    } catch (error) {
        console.log('Error occured during the capability token');
    }
};

function intitializeDevice() {
    device = new Twilio.Device(token, {
        logLevel: 1,
        enableRingingState: true,
        answerOnBridge: true,
        codecPreferences: ["opus", "pcmu"],
        //allowIncomingWhileBusy: true,
    });
    addDeviceListeners(device);
    device.register();
}
function addDeviceListeners(device) {
    device.on("registered", function () {
        console.log("Twilio.Device Ready to make and receive calls!");
    });

    device.on("error", function (error) {
        console.log("Twilio.Device Error: " + error.message);
    });
    
    device.on("incoming", handleIncomingCall);
    // if (device.audio.isOutputSelectionSupported) {
    //     //audioSelectionDiv.classList.remove("hide");
    // }
}

async function makeOutgoingCall(value, countryCode,  voiceCallNumber) {
    value='+'+countryCode+value;
    //console.log(value + " Call connect TwilioDevice " +voiceCallNumber);
    var params = {
        To: value,
        From: '+19168243760',// voiceCallNumber;
        // statusCallbackEvent: ['initiated', 'ringing', 'answered', 'completed'],
        // statusCallback:'https://mahogany-beagle-9825.twil.io/statuscallback',
        // statusCallbackMethod:'POST'
    };

    if (device) {
        console.log(`Attempting to call ${params.To} ...`);
        // Twilio.Device.connect() returns a Call object
        call = await device.connect({ params });
        console.log(call.CallSid + "  " +call.To);
        // add listeners to the Call
        // "accepted" means the call has finished connecting and the state is now "open"
        notifyOutgoingCallDetail(call);
        call.on("accept", function () { statusNotificationFromSDK('accepted'); });
        call.on("disconnect", function () { statusNotificationFromSDK('disconnected'); });
        call.on("reject", function () { statusNotificationFromSDK('rejected'); });
        call.on("cancel", function () { statusNotificationFromSDK('cancelled'); });

        call.on("initiated", function () { console.log('--initiated--'); });
        call.on("ringing", function () { console.log('--ringing--'); });
        call.on("answered", function () { console.log('--answered--'); });
        call.on("completed", function () { console.log('--completed--'); });

    } else {
        console.log("Unable to make call.");
    }
}
function handleIncomingCall(call) {
    //console.log(`Incoming call from ${call.parameters.From}`);
    callSid=call.parameters.CallSid;
    //console.log(`call sid ----  ${callSid}`);
    if(incomingCallCapability == false || device.isBusy){
        call.reject();
        // notifyIncomingCallDetail(call.parameters.From, call,callSid);
        // statusNotificationFromSDK("cancelled");
    }
    notifyIncomingCallDetail(call.parameters.From, call,callSid);
    // add event listener to call object

    call.on("accept", function () { statusNotificationFromSDK('accepted'); });
    call.on("disconnect", function () { statusNotificationFromSDK("disconnected"); });
    call.on("reject", function () { statusNotificationFromSDK('rejected'); });
    call.on("cancel", function () { statusNotificationFromSDK("cancelled"); });
}

function updateUIAcceptedOutgoingCall() {
    console.log("Call in progress ...");
    statusNotificationFromSDK('connecting');
}
function handleDisconnectedIncomingCall() {
    console.log("Call discomnected ...");
    statusNotificationFromSDK('disconnected');
}
function handleCancelledIncomingCall() {
    console.log("Call cancelled ...");
    statusNotificationFromSDK('cancelled');
}

function updateUIDisconnectedOutgoingCall(call) {
    console.log("updateUIDisconnectedOutgoingCall ...");
}
