self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var A={
bxt(){return new A.GR(null)},
GR:function GR(d){this.a=d},
a5C:function a5C(d){this.a=null
this.b=d
this.c=null}},C,B
A=a.updateHolder(c[4],A)
C=c[2]
B=c[0]
A.GR.prototype={
O(){return new A.a5C(C.t)}}
A.a5C.prototype={
V(){var y,x,w
this.Y()
y=$.bqB()
x=$.baK()
w=$.bqz()
$.l4().jk("redirectToPage",[y+"?client_id="+x+"&reply_url="+w])},
F(d,e){var y=null
return B.aBr(y,B.e(y,B.cf(new B.zh(y,y,y,y,y,y,y),y,y),C.c,y,y,y,y,y,y,y,y,y,y,y))}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(A.GR,B.Y)
y(A.a5C,B.a0)})()
B.bdX(b.typeUniverse,JSON.parse('{"GR":{"Y":[],"i":[]},"a5C":{"a0":["GR"]}}'));(function lazyInitializers(){var y=a.lazy
y($,"bLZ","bqB",()=>B.yx("breakGlassIdsUri"))
y($,"bLX","bqz",()=>B.yx("breakGlassIdsRedirectCallbackUri"))})()}
$__dart_deferred_initializers__["iezS1P+50wk8/+rCwMvPpiv1b5U="] = $__dart_deferred_initializers__.current
